# Polygon Split By Ratio (QGIS plugin)

Splits a selected polygon into any number of parts according to given
area ratios (e.g. `3,2,1`). The cut lines run parallel to a reference
line the user selects (e.g. a road, or a compartment boundary), which
makes this useful for forestry stand/compartment subdivision and
similar cadastral or planning tasks.

Magyarul: a kiválasztott poligont tetszőleges számú részre osztja a
megadott területarányok szerint (pl. `3,2,1`), a vágóvonalak egy
kiválasztott referenciavonallal (pl. út, tag-/részlethatár)
párhuzamosak. Hasznos erdészeti részlet-felosztáshoz és hasonló
kataszteri/tervezési feladatokhoz.

## Usage / Használat

1. Have a polygon layer (the shape to split) and a line layer
   (defines the cut direction) loaded in QGIS.
2. Open **Plugins → Poligon felosztás / vágás...** — a small chooser
   window opens where you pick one of the two tools below.

### Arányok szerinti felosztás

Válaszd a **"Arányok szerinti felosztás"** gombot a felugró ablakban.
Select the polygon layer, the line layer, and enter the ratios
(comma-separated, e.g. `3,2,1`). Click OK — a new memory layer
`felosztott_reszek` is created with the resulting parts
(`resz_sorszam`, `arany`, `terulet` fields).

Ha egyik rétegen sincs kijelölés és a rétegnek pontosan egy eleme van,
azt használja a plugin automatikusan; egyébként pontosan egy elemet
kell kijelölni mindkét rétegen.

## Terület alapú vágás (patak mentén) / Area-based cut

A felugró választó ablakban válaszd a **"Terület alapú vágás (patak
mentén)"** gombot.

Pontos célterületet (pl. `3,12` ha) vág le egy valódi vágó vonaltól
(pl. patak, a töréspontjaival együtt) kezdve, egy külön megadott
irányvonallal párhuzamosan.

1. Legyen egy poligon réteg (a felosztandó erdőrészlet), egy vonal
   réteg a vágáshoz (pl. patak, a valódi töréspontjaival), és egy
   másik vonal réteg, amellyel a vágás párhuzamos legyen.
2. Nyisd meg: **Plugins → Terület alapú vágás (patak mentén)...**
3. Válaszd ki a három réteget, add meg a célterületet hektárban.
4. **Irányszabály**: az irányvonal kezdőpontjától a végpontja felé
   nézve, jobb kéz felől kerül lemérésre a terület. Ha a rossz oldalt
   kapod, pipáld be az "Irány megfordítása" opciót és futtasd újra.
5. Eredmény: egy `kivagott_terulet` memóriaréteg, benne a kivágott
   résszel (`kivagott_resz`), az azonos oldalon maradó résszel
   (`maradek_azonos_oldal`), és a vágóvonal túloldalán lévő,
   érintetlen résszel (`tulso_oldal`).

A poligon rétegnek vetületi (méter alapú, pl. EOV/EPSG:23700)
koordinátarendszerben kell lennie a pontos hektárszámításhoz.

## License

GPL v2+ — see [LICENSE](LICENSE).
