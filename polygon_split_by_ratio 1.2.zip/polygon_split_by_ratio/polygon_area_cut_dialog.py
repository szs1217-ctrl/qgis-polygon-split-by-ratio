from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QFormLayout, QDialogButtonBox, QLabel,
    QCheckBox, QDoubleSpinBox
)
from qgis.gui import QgsMapLayerComboBox
from qgis.core import QgsMapLayerProxyModel


class PolygonAreaCutDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Terulet alapu vagas (patak menten)")
        self.resize(460, 300)

        layout = QVBoxLayout(self)

        info = QLabel(
            "Valaszd ki a felosztando poligont, a vago vonalat (pl. patak - "
            "a toresponjaival egyutt), es egy iranyvonalat, amellyel a "
            "vagas parhuzamos lesz. A celterulet a vago vonaltol kezdve "
            "kerul lemeresre.\n\n"
            "Iranykonvencio: az iranyvonal kezdopontjatol a vegpontja fele "
            "nezve, JOBB kez felol merjuk a teruletet. Ha a rossz oldalt "
            "kapod eredmenyul, pipald be az 'Irany megforditasa' opciot es "
            "futtasd ujra."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        form = QFormLayout()

        self.polygonCombo = QgsMapLayerComboBox()
        self.polygonCombo.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        form.addRow("Felosztando poligon reteg:", self.polygonCombo)

        self.cutLineCombo = QgsMapLayerComboBox()
        self.cutLineCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Vago vonal (pl. patak):", self.cutLineCombo)

        self.dirLineCombo = QgsMapLayerComboBox()
        self.dirLineCombo.setFilters(QgsMapLayerProxyModel.LineLayer)
        form.addRow("Iranyvonal (ezzel parhuzamos a vagas):", self.dirLineCombo)

        self.areaSpin = QDoubleSpinBox()
        self.areaSpin.setDecimals(4)
        self.areaSpin.setRange(0.0001, 1000000.0)
        self.areaSpin.setSuffix(" ha")
        self.areaSpin.setValue(1.0)
        form.addRow("Cel terulet:", self.areaSpin)

        self.invertCheck = QCheckBox("Irany megforditasa")
        form.addRow("", self.invertCheck)

        layout.addLayout(form)

        self.buttonBox = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)
        layout.addWidget(self.buttonBox)

    def getPolygonLayer(self):
        return self.polygonCombo.currentLayer()

    def getCutLineLayer(self):
        return self.cutLineCombo.currentLayer()

    def getDirLineLayer(self):
        return self.dirLineCombo.currentLayer()

    def getTargetAreaHa(self):
        return self.areaSpin.value()

    def getInvert(self):
        return self.invertCheck.isChecked()
