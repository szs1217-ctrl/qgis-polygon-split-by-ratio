from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton


class ToolChooserDialog(QDialog):
    RATIO = "ratio"
    AREA = "area"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Poligon vagas")
        self.resize(360, 160)
        self.choice = None

        layout = QVBoxLayout(self)

        label = QLabel("Melyik eszkozt szeretned hasznalni?")
        layout.addWidget(label)

        ratio_btn = QPushButton("Aranyok szerinti felosztas")
        ratio_btn.clicked.connect(self._choose_ratio)
        layout.addWidget(ratio_btn)

        area_btn = QPushButton("Terulet alapu vagas (patak menten)")
        area_btn.clicked.connect(self._choose_area)
        layout.addWidget(area_btn)

    def _choose_ratio(self):
        self.choice = self.RATIO
        self.accept()

    def _choose_area(self):
        self.choice = self.AREA
        self.accept()
