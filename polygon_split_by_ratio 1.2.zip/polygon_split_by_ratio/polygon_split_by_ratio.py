import os
import math

from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant
from qgis.core import (
    QgsGeometry, QgsPointXY, QgsField, QgsVectorLayer,
    QgsProject, QgsFeature, QgsCoordinateTransform
)

from .polygon_split_by_ratio_dialog import PolygonSplitByRatioDialog
from .polygon_area_cut_dialog import PolygonAreaCutDialog
from .tool_chooser_dialog import ToolChooserDialog


class PolygonSplitByRatio:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = "Poligon felosztas arany szerint"
        self.dlg = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Poligon felosztas / vagas...", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu(self.menu, self.action)
        self.iface.addToolBarIcon(self.action)
        self.actions.append(self.action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)

    def run(self):
        chooser = ToolChooserDialog(self.iface.mainWindow())
        if not chooser.exec_():
            return

        if chooser.choice == ToolChooserDialog.RATIO:
            self._run_ratio_tool()
        elif chooser.choice == ToolChooserDialog.AREA:
            self._run_area_tool()

    def _run_ratio_tool(self):
        dlg = PolygonSplitByRatioDialog(self.iface.mainWindow())
        if not dlg.exec_():
            return

        polygon_layer = dlg.getPolygonLayer()
        line_layer = dlg.getLineLayer()
        ratios = dlg.getRatios()

        if polygon_layer is None or line_layer is None:
            QMessageBox.warning(
                self.iface.mainWindow(), "Hiba",
                "Valassz ki egy poligon es egy vonal reteget!"
            )
            return

        if ratios is None:
            QMessageBox.warning(
                self.iface.mainWindow(), "Hiba",
                "Adj meg legalabb ket, vesszovel elvalasztott pozitiv szamot "
                "az aranyokhoz (pl. 3,2,1)!"
            )
            return

        poly_feat = self._get_single_feature(polygon_layer, "poligon")
        if poly_feat is None:
            return

        line_feat = self._get_single_feature(line_layer, "vonal")
        if line_feat is None:
            return

        line_geometry = self._to_layer_crs(line_feat.geometry(), line_layer, polygon_layer)

        try:
            result_geoms = self.split_polygon(
                poly_feat.geometry(), line_geometry, ratios
            )
        except Exception as e:
            QMessageBox.critical(
                self.iface.mainWindow(), "Hiba a feldolgozas soran", str(e)
            )
            return

        crs = polygon_layer.crs().authid()
        out = QgsVectorLayer(f"Polygon?crs={crs}", "felosztott_reszek", "memory")
        prov = out.dataProvider()
        prov.addAttributes([
            QgsField("resz_sorszam", QVariant.Int),
            QgsField("arany", QVariant.Double),
            QgsField("terulet", QVariant.Double),
        ])
        out.updateFields()

        for i, (g, a) in enumerate(zip(result_geoms, ratios), start=1):
            f = QgsFeature()
            f.setGeometry(g)
            f.setAttributes([i, a, g.area()])
            prov.addFeature(f)

        QgsProject.instance().addMapLayer(out)
        QMessageBox.information(
            self.iface.mainWindow(), "Kesz",
            f"A poligon {len(ratios)} reszre lett felosztva."
        )

    def _run_area_tool(self):
        dlg = PolygonAreaCutDialog(self.iface.mainWindow())
        if not dlg.exec_():
            return

        polygon_layer = dlg.getPolygonLayer()
        cut_line_layer = dlg.getCutLineLayer()
        dir_line_layer = dlg.getDirLineLayer()
        target_ha = dlg.getTargetAreaHa()
        invert = dlg.getInvert()

        if polygon_layer is None or cut_line_layer is None or dir_line_layer is None:
            QMessageBox.warning(
                self.iface.mainWindow(), "Hiba",
                "Valassz ki egy poligon, egy vago vonal es egy iranyvonal reteget!"
            )
            return

        if polygon_layer.crs().isGeographic():
            QMessageBox.warning(
                self.iface.mainWindow(), "Hiba",
                "A poligon reteg foldrajzi (fok alapu) koordinatarendszerben "
                "van - hasznalj vetuleti (meter alapu) rendszert (pl. EOV) "
                "a pontos teruletszamitashoz."
            )
            return

        poly_feat = self._get_single_feature(polygon_layer, "poligon")
        if poly_feat is None:
            return
        cut_feat = self._get_single_feature(cut_line_layer, "vago vonal")
        if cut_feat is None:
            return
        dir_feat = self._get_single_feature(dir_line_layer, "iranyvonal")
        if dir_feat is None:
            return

        cut_geom = self._to_layer_crs(cut_feat.geometry(), cut_line_layer, polygon_layer)
        dir_geom = self._to_layer_crs(dir_feat.geometry(), dir_line_layer, polygon_layer)

        target_area_m2 = target_ha * 10000.0

        try:
            cut_part, remainder_same_side, other_side = self.area_cut(
                poly_feat.geometry(), cut_geom, dir_geom, target_area_m2, invert
            )
        except Exception as e:
            QMessageBox.critical(
                self.iface.mainWindow(), "Hiba a feldolgozas soran", str(e)
            )
            return

        crs = polygon_layer.crs().authid()
        out = QgsVectorLayer(f"Polygon?crs={crs}", "kivagott_terulet", "memory")
        prov = out.dataProvider()
        prov.addAttributes([
            QgsField("nev", QVariant.String),
            QgsField("terulet_m2", QVariant.Double),
            QgsField("terulet_ha", QVariant.Double),
        ])
        out.updateFields()

        entries = [("kivagott_resz", cut_part)]
        if remainder_same_side is not None and not remainder_same_side.isEmpty():
            entries.append(("maradek_azonos_oldal", remainder_same_side))
        if other_side is not None and not other_side.isEmpty():
            entries.append(("tulso_oldal", other_side))

        for name, g in entries:
            f = QgsFeature()
            f.setGeometry(g)
            area_m2 = g.area()
            f.setAttributes([name, area_m2, area_m2 / 10000.0])
            prov.addFeature(f)

        QgsProject.instance().addMapLayer(out)
        QMessageBox.information(
            self.iface.mainWindow(), "Kesz",
            f"A kivagott resz terulete: {cut_part.area() / 10000.0:.4f} ha "
            f"(cel: {target_ha:.4f} ha)."
        )

    def _to_layer_crs(self, geom, from_layer, to_layer):
        if from_layer.crs() != to_layer.crs():
            transform = QgsCoordinateTransform(
                from_layer.crs(), to_layer.crs(), QgsProject.instance()
            )
            g = QgsGeometry(geom)
            g.transform(transform)
            return g
        return QgsGeometry(geom)

    def _get_single_feature(self, layer, label):
        feats = list(layer.selectedFeatures())
        if feats:
            if len(feats) > 1:
                QMessageBox.warning(
                    self.iface.mainWindow(), "Hiba",
                    f"Tobb {label} van kijelolve - jelolj ki pontosan egyet, "
                    f"vagy torold a kijelolest, ha a reteg csak egy elemet tartalmaz!"
                )
                return None
            return feats[0]

        feats = list(layer.getFeatures())
        if len(feats) != 1:
            QMessageBox.warning(
                self.iface.mainWindow(), "Hiba",
                f"Jelolj ki pontosan egy {label}t a megfelelo retegen (vagy "
                f"a retegnek csak egy eleme legyen)!"
            )
            return None
        return feats[0]

    @staticmethod
    def split_polygon(geom, line_geom, ratios):
        geom = QgsGeometry(geom)

        if line_geom.isMultipart():
            parts = line_geom.asMultiPolyline()
            if not parts:
                raise ValueError("A vonal geometriaja ures.")
            line_pts = parts[0]
        else:
            line_pts = line_geom.asPolyline()

        if len(line_pts) < 2:
            raise ValueError("A vonalnak legalabb 2 pontbol kell allnia.")

        p0, p1 = line_pts[0], line_pts[-1]
        dx, dy = p1.x() - p0.x(), p1.y() - p0.y()
        if dx == 0 and dy == 0:
            raise ValueError("A vonal ket vegpontja megegyezik, nem hatarozza meg az iranyt.")

        angle_deg = math.degrees(math.atan2(dy, dx))
        center = p0

        geom_rot = QgsGeometry(geom)
        geom_rot.rotate(angle_deg, center)

        if geom_rot.isEmpty():
            raise ValueError("A poligon geometriaja ervenytelen vagy ures.")

        bbox = geom_rot.boundingBox()
        total_area = geom_rot.area()
        if total_area <= 0:
            raise ValueError("A kivalasztott poligon terulete nulla vagy ervenytelen.")

        ratio_sum = sum(ratios)
        target_areas = [total_area * r / ratio_sum for r in ratios]

        y0, y1 = bbox.yMinimum(), bbox.yMaximum()
        x0, x1 = bbox.xMinimum() - 1, bbox.xMaximum() + 1

        def strip_geom(a, b):
            pts = [
                QgsPointXY(x0, a), QgsPointXY(x1, a),
                QgsPointXY(x1, b), QgsPointXY(x0, b), QgsPointXY(x0, a)
            ]
            return QgsGeometry.fromPolygonXY([pts])

        def find_cut(start, target_area, upper):
            lo_, hi_ = start, upper
            for _ in range(60):
                mid = (lo_ + hi_) / 2
                part = geom_rot.intersection(strip_geom(start, mid))
                if part.area() < target_area:
                    lo_ = mid
                else:
                    hi_ = mid
            return (lo_ + hi_) / 2

        parts_rot = []
        current = y0
        for target in target_areas[:-1]:
            cut = find_cut(current, target, y1)
            parts_rot.append(geom_rot.intersection(strip_geom(current, cut)))
            current = cut
        parts_rot.append(geom_rot.intersection(strip_geom(current, y1)))

        result = []
        for r in parts_rot:
            r2 = QgsGeometry(r)
            r2.rotate(-angle_deg, center)
            result.append(r2)

        return result

    @staticmethod
    def _line_points(line_geom):
        if line_geom.isMultipart():
            parts = line_geom.asMultiPolyline()
            if not parts:
                raise ValueError("A vonal geometriaja ures.")
            return parts[0]
        return line_geom.asPolyline()

    @staticmethod
    def _extend_line(points, bbox):
        margin = (bbox.width() + bbox.height()) * 2 + 1000.0

        p0, p1 = points[0], points[1]
        dx, dy = p1.x() - p0.x(), p1.y() - p0.y()
        length = math.hypot(dx, dy)
        if length == 0:
            raise ValueError("A vonal elso ket pontja megegyezik.")
        ux, uy = dx / length, dy / length
        start_ext = QgsPointXY(p0.x() - ux * margin, p0.y() - uy * margin)

        pn_1, pn = points[-2], points[-1]
        dx2, dy2 = pn.x() - pn_1.x(), pn.y() - pn_1.y()
        length2 = math.hypot(dx2, dy2)
        if length2 == 0:
            raise ValueError("A vonal utolso ket pontja megegyezik.")
        ux2, uy2 = dx2 / length2, dy2 / length2
        end_ext = QgsPointXY(pn.x() + ux2 * margin, pn.y() + uy2 * margin)

        return [start_ext] + list(points) + [end_ext]

    def area_cut(self, poly_geom, cut_line_geom, dir_line_geom, target_area_m2, invert):
        poly_geom = QgsGeometry(poly_geom)

        cut_points = self._line_points(cut_line_geom)
        if len(cut_points) < 2:
            raise ValueError("A vago vonalnak legalabb 2 pontbol kell allnia.")

        dir_points = self._line_points(dir_line_geom)
        if len(dir_points) < 2:
            raise ValueError("Az iranyvonalnak legalabb 2 pontbol kell allnia.")

        # 1) poligon kettevagasa a valodi vago vonal (pl. patak) menten,
        #    a torespontok megtartasaval - csak a ket vegen hosszabbitjuk meg
        extended_cut = self._extend_line(cut_points, poly_geom.boundingBox())
        work_geom = QgsGeometry(poly_geom)
        split_result = work_geom.splitGeometry(extended_cut, False)

        if len(split_result) == 2:
            error_code, new_geoms = split_result
        else:
            error_code, new_geoms = split_result[0], split_result[1]

        parts = [work_geom] + list(new_geoms)
        parts = [p for p in parts if p is not None and not p.isEmpty() and p.area() > 0]

        if len(parts) < 2:
            raise ValueError(
                "A vago vonal nem osztja ket reszre a poligont - ellenorizd, "
                "hogy a vonal tenylegesen athalad-e a kivalasztott teruleten."
            )
        if len(parts) > 2:
            parts = sorted(parts, key=lambda g: g.area(), reverse=True)[:2]

        # 2) forgassunk ugy, hogy az iranyvonal vizszintes (+x) legyen
        p0, p1 = dir_points[0], dir_points[-1]
        dx, dy = p1.x() - p0.x(), p1.y() - p0.y()
        if dx == 0 and dy == 0:
            raise ValueError("Az iranyvonal ket vegpontja megegyezik.")
        angle_deg = math.degrees(math.atan2(dy, dx))
        center = p0

        rotated_parts = []
        for p in parts:
            rp = QgsGeometry(p)
            rp.rotate(angle_deg, center)
            rotated_parts.append(rp)

        centroids_y = [rp.centroid().asPoint().y() for rp in rotated_parts]

        # jobb kez szabaly: +x iranyba haladva (p0 -> p1) jobb kez fele -y
        # esik, ezert alapertelmezetten az alacsonyabb rotalt Y-u reszt
        # valasztjuk celkent.
        target_idx = 0 if centroids_y[0] < centroids_y[1] else 1
        if invert:
            target_idx = 1 - target_idx
        other_idx = 1 - target_idx

        target_part = parts[target_idx]
        target_part_rot = rotated_parts[target_idx]

        target_area_available = target_part_rot.area()
        if target_area_m2 > target_area_available:
            raise ValueError(
                f"A megadott celterulet ({target_area_m2 / 10000.0:.4f} ha) "
                f"nagyobb, mint a rendelkezesre allo terulet ezen az oldalon "
                f"({target_area_available / 10000.0:.4f} ha)."
            )

        bbox = target_part_rot.boundingBox()
        y0, y1 = bbox.yMinimum(), bbox.yMaximum()
        x0, x1 = bbox.xMinimum() - 1, bbox.xMaximum() + 1

        def strip_geom(a, b):
            lo, hi = min(a, b), max(a, b)
            pts = [
                QgsPointXY(x0, lo), QgsPointXY(x1, lo),
                QgsPointXY(x1, hi), QgsPointXY(x0, hi), QgsPointXY(x0, lo)
            ]
            return QgsGeometry.fromPolygonXY([pts])

        # a patakhoz kozelebbi el az, amelyik oldalon a masik resz talalhato
        start_at_top = centroids_y[target_idx] < centroids_y[other_idx]
        if start_at_top:
            start, upper = y1, y0
        else:
            start, upper = y0, y1

        lo_t, hi_t = 0.0, 1.0
        cut = start
        for _ in range(60):
            mid_t = (lo_t + hi_t) / 2
            cut = start + mid_t * (upper - start)
            band = target_part_rot.intersection(strip_geom(start, cut))
            if band.area() < target_area_m2:
                lo_t = mid_t
            else:
                hi_t = mid_t

        cut_band_rot = target_part_rot.intersection(strip_geom(start, cut))
        remainder_rot = target_part_rot.difference(cut_band_rot)

        cut_band = QgsGeometry(cut_band_rot)
        cut_band.rotate(-angle_deg, center)
        remainder = QgsGeometry(remainder_rot)
        remainder.rotate(-angle_deg, center)

        other_part = parts[other_idx]

        return cut_band, remainder, other_part
